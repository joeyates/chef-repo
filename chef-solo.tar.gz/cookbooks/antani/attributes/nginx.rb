set[ :nginx ][ :ip ]            = '92.60.123.215'
