set[ :antani ][ :hostname ]     = 'antani'
set[ :antani ][ :ssh ][ :port ] = '41236'

set[ :apache2 ][ :ip ]          = '92.60.123.214'
set[ :nginx ][ :ip ]            = '92.60.123.215'
