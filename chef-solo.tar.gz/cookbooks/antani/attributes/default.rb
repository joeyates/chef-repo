set[ :antani ][ :hostname ]     = 'antani'
set[ :antani ][ :ssh ][ :port ] = '41236'
set[ :nginx ][ :src_binary ]    = '/usr/sbin/nginx'
set[ :nginx ][ :ip ]            = '92.60.123.179'
