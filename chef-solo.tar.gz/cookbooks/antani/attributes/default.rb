set[ :antani ][ :hostname ]  = 'antani'
set[ :nginx ][ :src_binary ] = '/usr/sbin/nginx'
set[ :nginx ][ :ip ]         = '92.60.123.179'
set[ :gitosis ][ :home ]     = '/var/gitosis'
