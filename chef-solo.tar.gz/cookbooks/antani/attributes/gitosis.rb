set[ :gitosis ][ :home ]        = '/var/git'
set[ :gitosis ][ :user ]        = 'git'
