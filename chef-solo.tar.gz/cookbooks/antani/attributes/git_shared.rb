set[ :git_shared ][ :home ] = '/var/git'
