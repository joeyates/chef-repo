#
# Cookbook Name:: antani
# Recipe:: default
#
# Copyright 2011, Example Com
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

#######################
# System settings

template '/etc/hostname' do
  source 'hostname.erb'
end

execute 'set hostname' do
  command "hostname #{ node[ :hostname ] }"
  action :run
  not_if { File.exists?('/etc/hostname') && File.open('/etc/hostname').read =~ /^#{ node[ :hostname ] }$/ }
end

#######################
# repositories

apt_repository 'ppa-p-balazs' do
  uri 'http://ppa.launchpad.net/p-balazs/postgresql/ubuntu'
  distribution node['lsb']['codename']
  components ['main']
  keyserver 'keyserver.ubuntu.com'
  key 'B89FA6AA'
  action :add
end

=begin

apt_repository 'ppa-ubuntugis' do
  uri 'http://ppa.launchpad.net/ubuntugis/ppa/ubuntu'
  distribution node['lsb']['codename']
  components ['main']
  keyserver 'keyserver.ubuntu.com'
  key '314DF160'
  action :add
end

=end

#######################
# Various packages

include_recipe 'nginx'

[ 'zsh', 'git-core', 'aptitude' ].each do | p |
  package p do
    action :install
  end
end

#######################
# postgresql and postgis

# Normal install runs initdb without setting the encoding

if not File.directory?( '/var/lib/postgresql/9.1' )

  package 'postgresql-9.1' do
    action :install
  end

  # Repair encoding
  bash 're-create template databases with UTF8 encoding' do
    user 'root'
    code <<-EOH
    pg_dropcluster --stop 9.1 main
    pg_createcluster --encoding=UTF8 --start 9.1 main
    EOH
  end

  [ 'postgresql-9.1-postgis', 'postgresql-server-dev-9.1' ].each do | p |
    package p do
      action :install
    end
  end

end

########################
# users

key_file  = '/root/antani_data_bag_key'
secret    = Chef::EncryptedDataBagItem.load_secret( key_file )
data_bag  = Chef::EncryptedDataBagItem.load( 'users', 'all', secret )
all_users = data_bag[ 'users' ]

all_users.each do | u |
  home_dir = "/home/#{ u[ 'logon' ] }"

  user u[ 'logon' ] do
    shell u[ 'shell' ]
    home home_dir
    supports :manage_home => true
  end

  directory "#{ home_dir }/.ssh" do
    owner u[ 'logon' ]
    group u[ 'logon' ]
    mode '0700'
  end

  template "#{ home_dir }/.ssh/authorized_keys" do
    source 'authorized_keys.erb'
    owner u[ 'logon' ]
    group u[ 'logon' ]
    mode '0600'
    variables :ssh_keys => u[ 'public-keys' ]
  end

end

sudo_users = all_users.map { | u | u[ 'logon' ] }
group 'sudo' do
  members sudo_users
end
