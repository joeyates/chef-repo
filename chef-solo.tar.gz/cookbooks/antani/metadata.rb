maintainer       "Example Com"
maintainer_email "ops@example.com"
license          "Apache 2.0"
description      "Installs/Configures foobar"

version          "0.1"

depends "passenger_apache2:mod_rails"
